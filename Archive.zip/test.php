<?php
/**
 * Created by PhpStorm.
 * User: Capp
 * Date: 23/12/2016
 * Time: 14:39
 */

$url = 'http://144.217.80.224/service/api/api.php/users_ucopia?filter=phone';

$response = file_get_contents($url);

$response_encode = json_decode($response, true);

//echo $response_encode["users_ucopia"]["records"][0][1];
echo $response_encode["users_ucopia"]["records"][0][3];